##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2
Comment: GPGTools - https://gpgtools.org

iQEcBAABCgAGBQJUiFrdAAoJEJgKPw0B/gTfj9wH/jKLR8IIok79Jed4ENc8PHWX
zVg8skzcewyuIqceI+aRxhUODd9QZ7MiHrA/MimScA5eUl1b+2NfekdDywZ+OOoD
jhsX5DhI6sU71EfD2MFOHeR2bAG5PPJSTG7VhqnMrbDrWufS4qCjnUojr6f4iCfE
l6bulSvspSNPTie45kGQlrg1gGDSHGtVHsZHPq/BjtWtswVvMT/aS/jUROR7o7q7
5OhPM4dtLrD5MiRSDEK8ofy3DCP70Zg7dZU4HD/JvaoZmhho+aIJU8f4ncsCKDvj
Ers1CoWVDfGvlsN82QF9igxGDjoOqgB4FyXRZpAuA+PMUOGMPZSIM0tN/7Elyxg=
=FDVt
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
964582           kbpgp-1.2.0-min.js  76bdb01a85b8d7f1aaddb09758cacad12912648e604b303907e6099d76fb0b33
1610207          kbpgp-1.2.0.js      a93ac959ac33486e65f4bc487244748983c4b0e62973559fa2429f032cc96b26
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing