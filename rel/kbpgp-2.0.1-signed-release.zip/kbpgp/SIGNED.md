##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2
Comment: GPGTools - https://gpgtools.org

iQEcBAABCgAGBQJUmEZhAAoJEJgKPw0B/gTf1RgIAIQGvIUImZHDtnY2YLRoTEqe
6748bZMy91f5SkeH9kmnJPHoOXO9xW+iqcaJ06YWc9H3KfIv07q3ya0wWtvmFYrN
TI3RZ/HX1JVnL+lqV4aSpNd0zpjTuhx0/nU8D6fgCckq2W2tVvlTGiTFPbiQogVI
y4mdXgluV4mqldcFvB+06PQ+uvTi8Csn0hLmiPVKOIXNCSJxfbviz0UziyI8UP6s
+NezRz84AHR1fSg4iNMeiZmnUu1JcGlAoDOAzlTJ7NPBeYCHCy43DzkuMTOc2I9n
S1iOg96CKl7iNFVBZMF7QqT2UbNTzAt6efN6dItNXQBTsvb9xv5Wfn/AdrU2hpM=
=fC49
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
1035256          kbpgp-2.0.1-min.js  d76b0651a10b407a8b16ae0fdd6e1fb50c8907f11a352f3315e41a1465774a67
1717047          kbpgp-2.0.1.js      d6285c1e9d48361eded4b5369b80b0a57638549fc275f3cab8425742f2403586
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing