##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Comment: GPGTools - https://gpgtools.org

iQEcBAABCgAGBQJU09DcAAoJEJgKPw0B/gTfO/sH/jG9rX944wZISNM7Y2sAVuV/
RmMQStCDLiFbnMvUxYYhBFfvKns9TE8oEZTc6TDaMS7wLYAr7udGGF0ff7YHaEoo
jF75I4M/gvODdNrKmdizv/5Qwri6Fb7bf+wIc+WrpQFSGhWEDPeJ+wpQGL0GRcWC
0TPpiK/V2TRFplZZKdcTqAcdxYdSUAJ5tRAAhdwZk/TzU3osa6pqzKtoD8nOL+uq
nx7+aiMI1BvBqrrQZPGDKz5XcB7SVWTbxz9uSP+M/FvPnGmsj5geD02NuV0q9n+S
sAzKSHcMH/Ef2bp/IS7H2PTqfn97DnKNYzfmKuxm2yYDOAuhuSGZzhVK0zMZuWo=
=05Ws
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
1035375          kbpgp-2.0.3-min.js  287b0841f8251ae87b0395f2a6509b4b8ad1dcc50bde76bb9b4c64f262ad8443
1717192          kbpgp-2.0.3.js      1556abe4fab172c0924233c93bd1ab577a8cc70103e4a9cdb3da7652c9f61848
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing