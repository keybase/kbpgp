##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2.0.22 (Darwin)
Comment: GPGTools - https://gpgtools.org

iQEcBAABCgAGBQJUItOtAAoJEJgKPw0B/gTfsx4IAKGyQsBmnKUpt2ZFl6nfbxG9
RYwwlO00p3tVaFlCwPodhFSrArtHuK+1EGEcbvzJvWaGLCE/FxNtFYeYQvTNkjry
ecukzdHsVjE17CTM0TKUxkoyDha7OpPrUC74+wz+tNBV76ZelUp2+8RXNsuA1Bpu
0Jhuud3ztAZbimYIRIG07JRCwSWI+Py7k6Sob5j+kwFfgr9d2IPsSJ23M5zc5URA
g9AF9o4pLoFWzsdnFX8AaXZ3l+3qVQROW74FZQtgcobqKuPo99xrGj0qAAn/q1jn
50q+4xMgwItpYOYI4foitD9lppz6obq53kFH0mLanL4bnzVHXw+IJ7+WEbBd/dM=
=6xXa
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
925282           kbpgp-1.1.0-min.js  e3104de79cd0e81f69b5644e088c62a24b8593f98f42b86b8d5e4f6409391819
1556054          kbpgp-1.1.0.js      4ad8153c6839021ca72a4558dc695d9b98eccacc7956b3f9524f5bd79935b3bb
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing