##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2.0.22 (Darwin)
Comment: GPGTools - http://gpgtools.org

iQEcBAABAgAGBQJURa0fAAoJEJgKPw0B/gTfAvUIAI9hU+p9SV7aP+o3CVFVSppI
4M4vX6PyIHI4IbpomJdNU2LQ3fnHMjTExRphoT15ut80BeAIaFdMCOV2c4sq6qtX
TuxkdT7liQ5rbvn9zXtGXOz6tgN7QAU7Ue9+tDqrsxHrT7pDjUuLqBHsA2iuOvDe
iGrF04FqzZoDNFhtdhm7Q7re6FvINJx15Eh4HwwtnLIzDKqQvGcvf6ln3DLB7w0l
XbVGX/E2I4Vr7KhAWpWlvToy+pHchRAyV+kJYaBgZi1EB267U769sVLSfRljXt7q
7o0A+G1UvZwD77mHL7fnYYmz9b2rhjxIdKGShIM6P/xwhvzBAE+WftCOf43TrPo=
=D9Ij
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
919367           kbpgp-1.1.5-min.js  6242445614901d0010b70596bc5a9275a85516e035d27e76b01e9d92ea33f0d8
1547581          kbpgp-1.1.5.js      16d8c9e2263977e4b2cf1d4c58035763a740af6ad4c17c7f7c7d985fff37fb69
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing