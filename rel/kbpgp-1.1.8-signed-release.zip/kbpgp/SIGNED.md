##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2
Comment: GPGTools - https://gpgtools.org

iQEcBAABCgAGBQJUhbh2AAoJEJgKPw0B/gTfONMH/i77f99YEXxMZW54sAse1ODi
Vzb0if8nVD+IAemgJ+leLRWuprA+v/oamgao7ryCeVcaRobTE9OV3y7jJWEjTE9C
vj/MDi5uBTFNu4u+VSeT+buMtiXILXZezkVdNYpv3PGBMLFC2gH6qH4RdLIoeI/n
tRwoC36aGO01oDeldulbnJu+8Km0uAB8GzF2hKG6cCslCnQrBrYgUFtfb4owQM6m
m1hCBEMgVqiJgmii8GN6Ul7QWgCRdQnYa3YB+vIxVzUJF2yNX84ZfYkZlwxxnn4u
7kjQwwZlr5ESriQ/Y+dkMUpcUEdk2iOdQbiIIRx5r+ZJcFsWon9H82DVN86st3k=
=tUmi
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
929090           kbpgp-1.1.8-min.js  dbc51c37b1bf68cc82fefd921c6c4499ac10df870f1222e345d2ea2b0b31c2e0
1562388          kbpgp-1.1.8.js      de5c3ab239d8790ce349c0568c8e9db3c0289b24ba15aeef1dba5323dde67f14
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing