##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2.0.22 (Darwin)
Comment: GPGTools - https://gpgtools.org

iQEcBAABCgAGBQJUEFbXAAoJEJgKPw0B/gTfcREIAJGF8J6p1wjeXXclCBEOBELl
qLa38bP9pLXG7twDqbT1O1XUiKtZRKMkgQBM32sqeMOPemPVpLeFEsDd2ZiB83VO
y+T7I/wAaNE72cA6A+KBrtscdreKZ+L42NNeWndH85G3xHBilwXoUXDmMuwRJYhh
Ep4vrgfDwBRcCNY4JgbPVegxDOZyplDCWafHbHSgF7dLsuC230aQm3NJg7gd5GMX
IhO5v2Dv6JuGF+EYtlaAgdOHTqbA9jkJzeDO/g9QTdJT/B7MNV1T3BLUoiwEPI3a
rUWo46sbeGMhO2dN4fHtYO+ElIda2c9cxrqQWdU6XOLWBY1GD9Ef3IEqlcKutsU=
=0jbL
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
922251           kbpgp-1.0.3-min.js  8d1a8e4b1111f4f312c41c44b51ea3b7f8e8456dd9e6870dd9bc3a530321b4d8
1551120          kbpgp-1.0.3.js      aa5ad1aed630eed29cb403db78b5a79782b2e3bd0904448be55683f2bf9080cd
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing