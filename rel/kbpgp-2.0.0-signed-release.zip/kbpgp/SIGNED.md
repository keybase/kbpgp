##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2
Comment: GPGTools - https://gpgtools.org

iQEcBAABCgAGBQJUiIweAAoJEJgKPw0B/gTfjRIH/0QntzcVpl3OcJU8DG9K6B2n
2dfjyyXJbNPlLm5DkAPXy9aF+1oSJjQSCbY/eIjpgyJyisQ7ywSMTRdSStoQ5ypI
ACch/wOkvSeFZEgZ7uJ3FViCvVcaTNiFcNRonj322y1L7It2sQ2GlVAy84jENyii
dOSz7Oouz5hiyVl6wslegOZRyY3Z053kKChxexRTM8jVOUbRdkMhUXg5nzZFNQNZ
VzAS9doOkpj4Oq6m8zWRDEbt07SiVB3jifajHHlnkQr3vaoMwWZizYe6X1yte5Xs
A4Gf/ayPz+9QLVJkKBT1iDv0wJz8E8TItzNdLfdiYt9PwjGX6L7DaRy4rgsGm10=
=uHoK
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
1013110          kbpgp-2.0.0-min.js  ec8dfc40e2f925d7cf1a46643463d7dd91e170d7176ba9d23712cbe3ae7dd420
1682966          kbpgp-2.0.0.js      c2811126a25ee2bf0c67c20d3dd3c2a48abc3385482c2065064f9044c4288b5b
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing