##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2.0.22 (Darwin)
Comment: GPGTools - https://gpgtools.org

iQEcBAABCgAGBQJUNYreAAoJEJgKPw0B/gTft5UIAJr1fjoJo/BaMAqpf9XwcRnM
xoDDvyYTNUxmnn5gpoTUXWCNN6cr/dGeX+LKQu44ee6shrInAQOlDAaYfhcgC6gR
qLvKY5to5hFZa2mRV+ATUeEGHpNQju1JtP51iGxJeIVDXBk7Kux6FMd3mIGRzLtF
GE4P8qiqKYoLaqNRZh4qPDSnHbCAZ+Iozv+ekHRLK87VVQuMS9YcT87UZCjn00jI
oRIBWdDbHqwxq3yDrQqK0/tt0HIO56SbX+5gZ/etMTV4BXLKwwvLeccYeZMyU5ZY
8LAH1o1Cj8vq2wt5hbcqj5tkEyRFT2r1a9g6DtBhQ7oxMK+773HfffRs/6GyYJU=
=r4Vn
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
926939           kbpgp-1.1.3-min.js  b1c1dd0a8f9e6984c894d8fcb797eb852830120ecc42c781c722f5f6e524cad4
1558616          kbpgp-1.1.3.js      6a0341e46a7f3eed7fdb04bd9a2f97410784dee13c64d9541163ce54810ddead
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing