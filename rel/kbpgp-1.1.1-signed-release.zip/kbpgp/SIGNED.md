##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2.0.22 (Darwin)
Comment: GPGTools - http://gpgtools.org

iQEcBAABAgAGBQJULeO5AAoJEJgKPw0B/gTfupkIAKMRllFnMbmv3bVJ00Tpvv0N
hVCOADYmmR9nsQUjNUdKhDg8B2eJi/TzHz1OkZy+AxueqPkdzysBi2NGIOfmnRPL
XIgBg+oiyHfm0vZbN6NNhQS5fvvXjN7WQsaITZ8oXCB1xPghCgofvtzSSiCtuy7m
W/XKVmwkiz+SZiexv016rMqYxS04HFN7FEEK9fCUl7Afcv2USA5iJgEZwfCDhjZZ
wmnEPfWK9dh6PmMYEa5Bn8S4czD5d/23eU32TXmkA3Uyqo6G/8OBGMohaZh94skZ
riwhGA2ozvkhFnBVbSwztKVM1U4MTl5r3d+Xv7rpzbiiBWnMRtqTI4Ro5OYzHpA=
=ovYU
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
916822           kbpgp-1.1.1-min.js  614ff1ae85939f3f0fd3c92c8a69fab074918e2cabbfb3b91a0b038ed48de513
1543203          kbpgp-1.1.1.js      b636a2a36a169cbfc7de4f295f5b748a4c1e15e9b4e99bb2f71e7943c281a568
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing