##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2.0.22 (Darwin)
Comment: GPGTools - https://gpgtools.org

iQEcBAABCgAGBQJULv36AAoJEJgKPw0B/gTf4U8IAJXWdO/sdtWBOfcKDRAIQ+M7
kVstAGxYTF8NUCXwVk359zUnc7IslLW82WTkhAJaExtPQ3JxqaUnMr5gXVAbP9/R
SVeN5i1ZvF/SSqjsXaPA5WLVSzK24cFD5VbZ+q5xHJVXTfvdlfvDZxVNGFATAJDK
EgPT8KY4DX9xDZXUJ8t/b6SqB66LhGAW4mPidchN7CObv2ZeSU+kdZXC1nJBQ4w9
6r+9rn/gRr1UF6m/PbcLTJCk395KBp9ZGJQ/MsbxoX9UIaIF9QwlyRx0Rm+nQV6a
hB43WJybFI5aVWRg2gZZ42oJrz2gtLfoMmpQ1jcam19encm9rcOYOsZLRQ+hBRI=
=o9Zr
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
925895           kbpgp-1.1.2-min.js  f2523501a976f594f054b3f4dea096368d2b3301b7eddf1edd26338e8aae825b
1556826          kbpgp-1.1.2.js      c139655aa1bcbf57fe8cbdaf8737f78810aa35d4205aafc35106f7b3b7a8fe03
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing