##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2
Comment: GPGTools - http://gpgtools.org

iQEcBAABAgAGBQJUbUn5AAoJEJgKPw0B/gTfy7kIAK3o3k5B61h7y7rjBFbSsLik
GJftVSNCHSn5HbdAWPbv6QuNPVt3P00uKG94iQrjXRqo+BFA0SHSLFS9wlYyRbQs
jixfbgS7CD6nAyOl4xPq2plq+gJPkyuCrfS/dxkF+EXISSn11trURyFGhomeBoRw
FgEwseY/aBTEDE0iBQLBOl7M0r2z5GoO7zCJ6pa8QhbRpwamUvoF8boOcHlmGKw4
Lz+XUGVbhoG+9Ku5sGOwHTdPC7Edeoc6BqdbkWHgOZUDSkfxy7B3Sx1G26CBmeYv
Ly9PrESBct8tqiVecJiL5+4aqxVRSYfBLrM07n61ajfYxOenz4t+/G13+Y734yY=
=ILuY
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
919718           kbpgp-1.1.6-min.js  c5564b93ee1ccc5da8061600ac8f779dfb3058583d05ff26ab0e60b858a7c4fd
1548150          kbpgp-1.1.6.js      36025ddee3ac59af3c0c8db51cfe3b2edfbc31570bece22e31750c2c2bb618c1
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing