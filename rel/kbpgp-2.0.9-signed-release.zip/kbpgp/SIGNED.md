##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Comment: GPGTools - https://gpgtools.org

iQEcBAABCgAGBQJVCYRzAAoJEJgKPw0B/gTfTzUH/RL93sBy4h/7xw3829xAA4x9
UID2E/1QJNHyJKTlknPXWEt65R5YXvXWphuHz/cwA5uAKGVIHvrAL/WxcroJu7XU
GuQ0bjmqHcLuYlPKOu4dSa3ga7l4hDqA0aHBQ4Hkzhoo5LyORKj+wcSSg/9XnOWu
ujDDUP7XKNcKwuLlkAEy0AOjEC7fd6/hXWtOCTzzsCrFqJRHfJWUV3t2Lbf/6tgk
pvaSGcQWtAy6KGZY5J/kOnR7mH7/esi7DxaTfJhTyWJzCOJAPlUNOuyKdPQLW6dx
BvMeom3RRvu6GfpCHCj23GLd6S9bTp1ni8yWot4r8XwDOAaJo47Tan1HrDLXQMk=
=AVCI
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
1029402          kbpgp-2.0.9-min.js  a4b50e931881d0e722d6156f1763dfc8c401f8c87c02951e8cae1587d154740a
1708080          kbpgp-2.0.9.js      c13e9b0c6e381d51e4dbeaaf60a1a1fed631106f33f1186691d3dd6b7490d728
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing