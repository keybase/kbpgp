##### Signed by https://keybase.io/chris
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2.0.22 (Darwin)
Comment: GPGTools - https://gpgtools.org

iQIcBAABCgAGBQJTsvpRAAoJENIkQTsc+mSQV0EP/Rh3Chb00hsXEBGCmQ0ZIOW4
ZTaaf/StMNotV/dAq5OuSx23ErM2UvfV55J+Ei8Ej7gPJzff8SoyK+dMnoIIqcU4
cJ5NmJY8OIyTG4S82NZpKuEyPlSlfBWNnwit5DbpbTns8iXf2QGdtwYzuX52CeP/
xjQKCgI6ksqlLWTR4iSFOwSY8otDzI8cqiHPqN6oz+oXmRdGMnKnVKLQZ0BANjhI
QJ+akyB35tv4kLHsEEbP+hGH58DnRl2FdSuMNK858CEHRWS7UKMUJd9yjFtS+BXu
aciUrClHQA3xKJMwj9EMNAIy7BFqs62L8zs5vd3GHxzmpTmChahrbCgrRFy0UxF5
iqlk4K8uAFGOQy3X6xC4lzpCk5XnohjMDPw5Bv0mZWCTKJIoZAerkBgGkUGv88mQ
EUFdu96M7Tvv+jY6ihSucste7oG93Ly21NBSPCewI7Ayab4NhGkJfRsI47aje8QC
OOZE84di7p7wRJIvpgXQdZPrR7tI4BUddG0hJdDaPKxpfnrKMxosO6c92EF/akGE
keOWqhWzYKHOs3cNSP1wXnrYuaoOHJHzQl0PpGzonHlKQdV8/ZCZyqtZLzV0Z6nc
hDQbu2NBeYktM6bwNWeACEZ+UWgG0Hza/FQQxc4jtslwPsX5lGJuBNwHgfaIBav3
SVK7vvKCuBk6zq0mpAO0
=DVfs
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                   contents                                                                                                                         
               ./                                                                                                                                                      
764209           kbpgp-0.1.22-min.js  02317cbf0f73700a90839c4d170fb76e693255d06b36aed8c4b4560e5ca77ceb                                                                 
1187187          kbpgp-0.1.22.js      e367caa04c89a0978531c4ca8c6767edc5557ab7f31740269384ba3e695fd339|d090cd97503c1bd6c39a042e55911a0e2c8b5439966e5186d81686d61862015b
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing