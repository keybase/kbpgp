##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2.0.22 (Darwin)
Comment: GPGTools - https://gpgtools.org

iQEcBAABCgAGBQJURW3cAAoJEJgKPw0B/gTf/B8H+gOjlSJIA+qSL3n/unz9RSCt
PwnHMuvBararMrvOyICAezl8GWfNiX8tFCRVhpl1Y1ULgre/aJt0UFn6qboBmslQ
R3eTiFO5kqxMhFBj3z+1f/iRff/wALAnIO2pilmj/ZTbhmW68TdvbDNKDfEK1iMv
wzkD/5xlu/GUB8O+QS5X1ekemfn7EVfAdpWVriOxEFPT3JCli8V0a2WmDIFhVOV6
WRbVkyRO2pIm+9CUnFZRj40gUflb2+o6lDnjsiv8h0NgbiCodqo6aYam7kyibEdi
eDk2F34snjDiuUoi7BE/dhny1+9JKkVaI7o/RJKGZHLSrsIlFd+c+07xIjwBqDc=
=JgsB
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
927605           kbpgp-1.1.4-min.js  2bfdc54fef85340c7fe4773becd3600f9df21b80dc2947ede5841cf5bced743a
1560087          kbpgp-1.1.4.js      f4f92f7ce6b33a504fc21d029cd2be6466cd42d67a658506c5cf9620ef08d9f4
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing