##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2.0.22 (Darwin)
Comment: GPGTools - https://gpgtools.org

iQEcBAABCgAGBQJUGabCAAoJEJgKPw0B/gTfYusH/RkekB1vGkQaEZB/Eg/90zJz
wAXb3s6WonhFPDfEV+5E2YCyT46LjTBtjrlgjxeZEgMDWlzC9H0ioy9WuZqfCw8r
CVE6zStPaPvDSl3c/s93d5YEoJfStCnZt/Ei2mzYONFNYugiz8AgDxohqArFyChE
kg4Sb2ZtNDNUch2ioiO+PJ5mVz+nUu1TWuH7kQAseFY0yf3yY2nSOlwd06756GBd
2OXH9n/CZSsSPCa+tuLx3/UsPzhjkpSTo1R2PwsChNwMLmOHrF6x5sZY4tDi9sSs
6ILiUlBe0W6/g6wbKVOSSWDvqOxTWiaF10ldqucouFRZQoIq45bRyzWlYSUkBn4=
=ZwPY
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
922558           kbpgp-1.0.4-min.js  21ce1fbba3b8cf79acb0dc07f08e5538add08fce3040ee6af0a88e2e8faa6122
1551547          kbpgp-1.0.4.js      6a368bfce1492d134f27922089a97c41e17b0e75201fc7fc0a7dd470a63bd1de
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing