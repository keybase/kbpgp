##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2.0.22 (Darwin)
Comment: GPGTools - https://gpgtools.org

iQEcBAABCgAGBQJUGuuZAAoJEJgKPw0B/gTfBAwIAJTIcYdVd82waMULB13fG9UL
kSNXUAtPpmJkoRQp3d2Z5siInzmQsdeDkivQBwuERjNFA9fmcSEb8j1Jzuxtly2b
TO7og2ds9i8xz3ssvMmBv+JqYltEUYgDql42GZ2FC2t5ajNR1H/BrcJg/OeMCzVa
n+9cGGynO8VozUb9ObSWgyqZeN3huqlYv0flVzttaZtlLZytKB+iXRIws54pvOko
baSsBjcVJL40bVoEvJJPFUtf7H2LIZ+xHurCU8Tmvwjoskgxxit+WVYkgOtS0919
Tr515KtWRqPLPBdWKi4aeBcnfJHnFe+FnHxQYYH8xS4gjB1zLaitDL5B1yQa3ww=
=xkkI
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
922570           kbpgp-1.0.5-min.js  55eea344b43829fdbed8a54db21227f0b84fca2a5572d5f52e734f1121de92f4
1551567          kbpgp-1.0.5.js      ed4c72ba4e297f56054c404ba51c1f6129da1f208ff8f77900365b52bc345a37
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing