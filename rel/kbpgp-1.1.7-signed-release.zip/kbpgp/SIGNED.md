##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2
Comment: GPGTools - http://gpgtools.org

iQEcBAABAgAGBQJUdTmyAAoJEJgKPw0B/gTfETgH/05kE+9NWsGXUlFEDp4xCO3N
RJ2y1wLWSFOhtd29HQ4piZELmBE3CU/9vC0a4pXUxBGXhBMVLf6kszK1q03P+cB3
U5tUJeLzTWT2CzoYNUob6oPdRTXJmvnTYM0uux0kEQ54YxIink+F2tZvxlpKopzL
8F80I61nzRxYGzbVVHAHQEi3uKD8gth2n/ye+S/Fmz/Ju0cFByNq5O4V+6jzfPsp
qAvhPIYO6CVfKo4cuuPtch3JbkyQ2lnE2A/2OOGwKHwyfPHyqtrl035nlkn1kjhn
Seev4dzW6XcFj27dlUVh1ptWr0q1rOcfuVrAWgdhPg1shCCyubF9X5widhrurCc=
=D8qa
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
920660           kbpgp-1.1.7-min.js  3d190644a42018632a1044a76c2f361eca00be72b6093a6fc52fa7c94cc33517
1549567          kbpgp-1.1.7.js      68a07cb59400ece3b07e72704dce748daa995008db318f84b42922178edc15ca
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing