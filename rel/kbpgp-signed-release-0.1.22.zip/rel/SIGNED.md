##### Signed by https://keybase.io/chris
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2.0.22 (Darwin)
Comment: GPGTools - https://gpgtools.org

iQIcBAABCgAGBQJTsu4tAAoJENIkQTsc+mSQiJIP/A+Fg7IVXNqkzk3UR6dOBTEF
rbNUakS8b//2jl/FMhKvAC3WTKGNwxiA4+SsCcXh08l4NKMpbqBUX7lMdOnRA96y
A7VdVxzKiRYiNbqMqe3z02xkgnwyHNwOjZM/GhU9mEYkhakEMfhE+nNYMpKMlq1K
FmtHOp6xVcFr4kc/U5yGoaz8O/WERrThRZ+Lr4ZgberOTgFMDHqQWYBXmcWbRLEf
bSSu/ABFtVUb5bvMhOkYMvcIhqS9FnzO30Sq/T3bV0OY5lEO6JccDC9ZaxMnrAnA
C+/UruO+KIDbzQmoAunbphC/pILj89E5nHYFxT46o2M8sslVKuf0PJuB/NRYO1hG
7nkdM6HW5pGu/QkbQP4k2PSNOg87ggk/TEwluDxw+7FUTGiDDflgnGPY8+wBnE81
daUgCKa9IvuOKz1u/V3v6OQ0oK/dLA9MwWaAsAK9MC0kgKoiDQzPAGyGFQJZFIGo
E8lThQEvntSF7q1Otiw1OUfIBpxA1dh7ssJVtnSgsQL3w53xXeXOjFeDoazjTiEY
MZjYxtkppLdhMNan5DwmjGiSsr22uD1N0boDeWC8fX68CissEJxI03qp3Wai/pDy
aq991apjp5Fhqch8LHid6rXiA0wLIzJP9YwE3B0iUs8qZ6Z9hgsgQi9B/qSxQNGY
3nZ5WP3fldC3dlCpTBoo
=hzuh
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                   contents                                                                                                                         
               ./                                                                                                                                                      
743954           kbpgp-0.1.18-min.js  18e641a55e76ec6c784bbf7c43b5c52857cf5d28cdbf80b0c8697b31536a7c05                                                                 
1156031          kbpgp-0.1.18.js      0c1334ed7647f99127092e4032333376545e4b6770c7cd5b2f688066e2cce25a|e15b49f406ed5d75e32c8ca17e05b45e843e39d2f1d5b11f1467b8610ab43e56
753933           kbpgp-0.1.19-min.js  1e582443a072f7d90de67864e2a0ffe921bbd9af7d467b7d4bdef5494c90c79c                                                                 
1171371          kbpgp-0.1.19.js      bd03528931a40966742e203c8764f625e81c32e39c6d398164943923f06f5d17|e5097f78db6cb88a814576df859f290198eb14fbabf4a4ddfa3b8bce1fddc423
764209           kbpgp-0.1.22-min.js  02317cbf0f73700a90839c4d170fb76e693255d06b36aed8c4b4560e5ca77ceb                                                                 
1187187          kbpgp-0.1.22.js      e367caa04c89a0978531c4ca8c6767edc5557ab7f31740269384ba3e695fd339|d090cd97503c1bd6c39a042e55911a0e2c8b5439966e5186d81686d61862015b
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing