##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2
Comment: GPGTools - https://gpgtools.org

iQEcBAABCgAGBQJUh2JLAAoJEJgKPw0B/gTfO/AIALcd3SQeIuL+2wgAQRsMxkPi
MiB4tt5OC7W7Vo17b6Elvf1a+UgFRkwI/FTyZxTEyAEzLuOOugPdJ8Cniw/rf23W
iAVcy28GD5nUDPYzC8vLVRALeVEiOGXM7wd4fe3kjeIhKe8aReedATQ7NPuguDPf
YrcPEbYflMVnxJaQW2qDozRBn44UFQzR55NiJTqSSJ5a8ODq8iqMydnY3E3fv0bH
1VHhOCQZUq+i2PZAo9pX3DvZpxvXo2To8qodqJwjesArU3tPman8STNlDPKdfYLi
D9M09Awr7jZF+3mIRLiq74QCR3xLIOvtYC2C/Auf9ZtQWalZIUwgNsGgvjw5o8w=
=bzsK
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
929064           kbpgp-1.1.9-min.js  7a916e9fdcea2ed6c4754f89a25bd74d45c0d78ce2750a1d241a279073313705
1562361          kbpgp-1.1.9.js      1c70b313f870874e2d687ba08365ae3002a355264b1bb83b4667cdd2b746f1c5
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing