##### Signed by https://keybase.io/max
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG/MacGPG2 v2.0.22 (Darwin)
Comment: GPGTools - http://gpgtools.org

iQEcBAABAgAGBQJT9mYdAAoJEJgKPw0B/gTfwHEH/1pujY5wnp7yfAaU/S+UEVU2
/ceBmsvuBU+W/hs/EIchWP1lCNAFA/aMC9dPZeh1mEiqqPBevibX98kjoznMvIIi
QiZVHkJ1rzYWcoBOL2l5Oc3YrpBkvZTO+M188ildE+PDMsHahS3hKmVMw09UiSfy
RPVKRMlnykaLt7jMFU5myih2zSSONclqhIH9r8BvG85ACfVVyxNYFqIxil/jirhw
aYbM9/odJxSfGafXl6bmu/COHse6gMwpJC6IxGpG/oPzs4q90ncDviZmwIV+bP6a
UrZRz+A9WtOTVAAx9x3ofGv4f+6oh/glXzbWLykIIxDRl0lEvGU4AyN2CF3sv1g=
=R543
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size     exec  file                  contents                                                        
               ./                                                                                    
910039           kbpgp-1.0.2-min.js  c44740f5a87bf4dddffec07cbd7b8b1e866864dccd2098761666838000445f45
1533087          kbpgp-1.0.2.js      da855244c0857a3b3c1ffdd5c8ec00346001ef15837439e8e474b37d007a8347
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
none  # don't ignore anything
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing